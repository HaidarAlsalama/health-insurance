/** layout status start */
export const OPEN = "open";
export const HALF_OPEN = "halfOpen";
export const OPEN_SMALL = "openSmall";
export const CLOSE = "close";
/** layout status end */


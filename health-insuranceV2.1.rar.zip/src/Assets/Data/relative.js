const relative = ["أب", "أم", "زوج/زوجة", "ابن", "ابنة", "أخ", "أخت"];
export default relative;

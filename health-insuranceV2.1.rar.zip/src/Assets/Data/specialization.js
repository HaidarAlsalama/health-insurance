const specialization = ["الاختصاص 1", "الاختصاص2"];
export default specialization;

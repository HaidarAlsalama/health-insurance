const status = ["متزوج", "عازب","منفصل"];
export default status;

const gender = ["ذكر","أنثى"]
export default gender
const statusrelativee = ["متزوج", "عازب"];
export default statusrelativee;

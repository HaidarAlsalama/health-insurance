const paymethod = ["كاش", "تقسيط", "مكاتب هندسية"];
export default paymethod;

export const  _md_size = 768;
export const _lg_size = 1024;
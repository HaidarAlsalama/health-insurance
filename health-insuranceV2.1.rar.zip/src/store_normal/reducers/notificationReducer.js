const notificationReducer = (state = {}, action) => {
  switch (action.type) {
    default:
      return state;
  }
};

export default notificationReducer;
